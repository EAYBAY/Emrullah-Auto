# Emrullah Auto – özelleştirme notları

- Uygulama görünen adı: Emrullah Auto
- Uygulama servis adı: Emrullah Auto
- Görsel kimlik: turkuaz / koyu tonlar; beyaz EA monogramlı başlatıcı simgesi
- YouTube eklentisi adı: YouTube
- Türkçe kaynak dil paketi projede zaten mevcut (`values-tr`).
- YouTube eklentisi `modules/web` modülünde zaten bulunur; proje ayarlarında varsayılan olarak etkinleştirilir.
- Android Auto desteği kaynak projede zaten vardır.

## APK derleme

Android Studio / Android SDK + NDK ve Java 17 kurulu ortamda:

```bash
NO_GS=true ./gradlew fermata:packageAutoReleaseUniversalApk -PABI=arm64-v8a -PAPP_NAME="Emrullah Auto"
```

Bu çalışma ortamında Android SDK/NDK bulunmadığından APK burada derlenemedi. `.github/workflows/build-apk.yml` GitHub Actions iş akışı, proje GitHub deposuna gönderilip `Build APK` iş akışı çalıştırıldığında APK artifact'lerini üretir.

## Güvenlik notu

Kaynak projedeki YouTube/video işlevi araç durumunu güvenilir biçimde doğrulayan park kilidi olarak değiştirilmedi. Video oynatımını sürüş sırasında engelleme özelliği, araç durumunu sağlayan Android Auto/araç entegrasyonu ve gerçek araç testleri olmadan güvenli biçimde garanti edilemez.
